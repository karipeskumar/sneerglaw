package com.wba.eapi.producer.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Prescription{
	
	private String lineItem;
	private String prescriptionId;
	private String submissionStatus;
	private String patId;
	private int newStoreNumber;
	private int origStoreNumber;
	private String origRxNumber;
	private String newRxNumber;
	private boolean ninetyDayInd;
	private String fillPayMethodCode;
	private String refillStatusCode;	
	private Price price;
	private int retryCount;
	private String retryDateTm;
	
	public Prescription() {
		
	}
	
}
