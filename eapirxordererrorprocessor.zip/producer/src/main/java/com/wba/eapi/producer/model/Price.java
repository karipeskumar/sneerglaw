package com.wba.eapi.producer.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class Price {

	private String priceMsg;
	private double value;
	
	public Price() {

	}
}
