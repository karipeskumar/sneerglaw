package com.wba.eapi.producer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.wba.eapi.producer.model.OrderSubmissionDetails;

@RestController
@RequestMapping(value = "/producer")
public class EapiRxOrderErrorProcessorController {
	@Autowired
    private KafkaTemplate<String, OrderSubmissionDetails> kafkaTemplate;
	
	@Value("${kafka-topic-order}")
	private String orderKafkaTopic = "";
	
    @GetMapping(value = "/ping")
	public @ResponseBody String getResponse() {		
		return "OK";
	}
    @PostMapping(value = "/produce")
	public @ResponseBody String produceMessage(@RequestBody OrderSubmissionDetails orderSubmissionDetails) {	
    	kafkaTemplate.send(orderKafkaTopic, orderSubmissionDetails);
		return "OK";
	}

}
