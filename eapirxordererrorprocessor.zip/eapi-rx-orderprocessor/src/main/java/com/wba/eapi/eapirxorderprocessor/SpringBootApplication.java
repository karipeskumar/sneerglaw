package com.wba.eapi.eapirxorderprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;


@EnableAutoConfiguration
@org.springframework.boot.autoconfigure.SpringBootApplication
public class SpringBootApplication {

    public static void main(String[] args) {
    	System.out.println("*******************Application   Started******************************\n\n");
        SpringApplication.run(SpringBootApplication.class, args);
    }


}