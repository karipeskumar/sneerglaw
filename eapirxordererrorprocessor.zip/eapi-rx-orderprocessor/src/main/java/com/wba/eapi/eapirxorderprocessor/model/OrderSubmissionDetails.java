package com.wba.eapi.eapirxorderprocessor.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Setter
@Getter
@ToString
@Document(collection = "OrderSubmissionDetails")
public class OrderSubmissionDetails {

	@Id
    private String orderId;
    private Date selectedDate;
    private String selectedTime;
    private String submissionStatus;
    private int userSelectedStore;
    private String createDateTm;
    private String updateDateTm;
    private String userId;
    private List<Prescription> prescriptionsList;
    

    public OrderSubmissionDetails()
    {
    	
    }    
}
