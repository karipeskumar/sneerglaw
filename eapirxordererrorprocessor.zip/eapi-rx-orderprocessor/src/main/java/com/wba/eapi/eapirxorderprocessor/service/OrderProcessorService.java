package com.wba.eapi.eapirxorderprocessor.service;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import com.wba.eapi.eapirxorderprocessor.model.OrderSubmissionDetails;
import com.wba.eapi.eapirxorderprocessor.model.Prescription;

@Service
@PropertySource("classpath:application.properties")
public class OrderProcessorService {
	
	@Autowired
	private OrderProcessorRepository orderProcessorRepository;
	
	@Autowired
    private KafkaTemplate<String, OrderSubmissionDetails> kafkaTemplate;
	
	@Value("${kafka-topic-orderprocessor}")
	private String successTopic = "";
	
	@Value("${kafka-topic-ordererror}")
	private String failedTopic = "";


    @KafkaListener(topics = "${kafka-topic-order}", groupId = "${kafka.consumer.groupid}",
            containerFactory = "orderKafkaListenerFactory")
    public void consumeOrder(OrderSubmissionDetails orderSubmissionDetails) {
    	System.out.println("***************************************************");
    	System.out.println("\n\n\n Message read from Kafka topic \n\n"+orderSubmissionDetails);
    	
        orderProcessorRepository.insertOrderSubmissionDetails(orderSubmissionDetails);
        
        String orderStatus = orderSubmissionDetails.getSubmissionStatus();
        if(!(orderStatus.equalsIgnoreCase("success")||orderStatus.equalsIgnoreCase("partial success")||orderStatus.equalsIgnoreCase("failed")))
             processOrder(orderSubmissionDetails);
        System.out.println("***************************************************");
    }

    private void processOrder(OrderSubmissionDetails orderSubmissionDetails) {
    	//called Mock SAG flow
    	System.out.println("calling SAG mock\n\n");
    	OrderSubmissionDetails sagResponseOrderSubmissionDetails = sagCall(orderSubmissionDetails);
    	System.out.println("response from SAG mock \n\n"+orderSubmissionDetails+"\n\n");
    	
    	for(Prescription p:sagResponseOrderSubmissionDetails.getPrescriptionsList())
    	{ 
    		if(!p.getSubmissionStatus().equalsIgnoreCase("success"))
    		{
    			OrderSubmissionDetails errorOrder =  new OrderSubmissionDetails();
    			errorOrder.setOrderId(sagResponseOrderSubmissionDetails.getOrderId());
    			errorOrder.setSelectedDate(sagResponseOrderSubmissionDetails.getSelectedDate());
    			errorOrder.setSelectedTime(sagResponseOrderSubmissionDetails.getSelectedTime());
    			errorOrder.setSubmissionStatus(sagResponseOrderSubmissionDetails.getSubmissionStatus());
    			errorOrder.setUserSelectedStore(sagResponseOrderSubmissionDetails.getUserSelectedStore());
    			errorOrder.setCreateDateTm(sagResponseOrderSubmissionDetails.getCreateDateTm());
    			errorOrder.setUpdateDateTm(sagResponseOrderSubmissionDetails.getUpdateDateTm());
    			errorOrder.setUserId(sagResponseOrderSubmissionDetails.getUserId());
    			List<Prescription> prescriptionsList = new ArrayList<>();
    			prescriptionsList.add(p);
    			errorOrder.setPrescriptionsList(prescriptionsList);
    			
    			if(p.getRetryCount()<10)
    			   publishMessageToOrderErrorKafka(errorOrder);
    			
    		}
    	}
    	
    	
    	System.out.println("updating line items in DB with SAG response\n\n");
       	orderProcessorRepository.updateOrderSubmissionDetails(sagResponseOrderSubmissionDetails);
       	System.out.println("completed updating line items in DB\n\n");
       	
       	verifyOrderToPublishToResultsTopic(orderSubmissionDetails.getOrderId());
        
	}
    
    
    public void verifyOrderToPublishToResultsTopic(String orderID)
    {
    	OrderSubmissionDetails retrievedDbOrderSubmissionDetails = orderProcessorRepository.getOrderSubmissionDetailByOrderId(orderID);
    	int successCount = retrievedDbOrderSubmissionDetails.getPrescriptionsList().stream()
		.filter(p -> (p.getSubmissionStatus().equalsIgnoreCase("success"))).collect(Collectors.toList()).size();
    	int failedAndRetryCountExceeded = retrievedDbOrderSubmissionDetails.getPrescriptionsList().stream()
    			.filter(p -> (p.getSubmissionStatus().equalsIgnoreCase("failed")&&p.getRetryCount()>=10)).collect(Collectors.toList()).size();
    	int allFailedCount = retrievedDbOrderSubmissionDetails.getPrescriptionsList().stream()
    			.filter(p -> (p.getSubmissionStatus().equalsIgnoreCase("failed"))).collect(Collectors.toList()).size();
    	System.out.println("total prescription count : "+retrievedDbOrderSubmissionDetails.getPrescriptionsList().size());
    	System.out.println("success prescription count : "+successCount);
    	System.out.println("failed prescription count : "+allFailedCount);
    	System.out.println("failed prescription count exceeded max retries : "+failedAndRetryCountExceeded+"\n\n");
    	
		if(successCount==retrievedDbOrderSubmissionDetails.getPrescriptionsList().size())
    	{
			System.out.println("All prescriptions are success -- publishing success to results kafka\n\n");
    		retrievedDbOrderSubmissionDetails.setSubmissionStatus("success");
    		orderProcessorRepository.updateOrderSubmissionDetails(retrievedDbOrderSubmissionDetails);
    		publishMessageToOrderProcessorKafka(retrievedDbOrderSubmissionDetails);	
    	}
		else if(successCount>=1)
		{
			if(failedAndRetryCountExceeded==allFailedCount)
			{
				System.out.println("order has some success prescriptions but exceeded retries for all failed prescriptions -- publishing  partial success to results kafka\n\n");
				//partial success
				//DB update
				// publish to result kafka
	    		retrievedDbOrderSubmissionDetails.setSubmissionStatus("partial success");
	    		orderProcessorRepository.updateOrderSubmissionDetails(retrievedDbOrderSubmissionDetails);
	    		publishMessageToOrderProcessorKafka(retrievedDbOrderSubmissionDetails);	
			}
			else
			{
				// failed 
				//DB update
				retrievedDbOrderSubmissionDetails.setSubmissionStatus("in progress");
	    		orderProcessorRepository.updateOrderSubmissionDetails(retrievedDbOrderSubmissionDetails);
			}
		}
		else if(successCount==0)
		{
			if(failedAndRetryCountExceeded==allFailedCount)
			{
				System.out.println("order has all failed prescriptions and exceeded retries for all failed prescriptions -- publishing failed to results kafka\n\n");
				//Failed
				//DB update
				// publish to result kafka
	    		retrievedDbOrderSubmissionDetails.setSubmissionStatus("failed");
	    		orderProcessorRepository.updateOrderSubmissionDetails(retrievedDbOrderSubmissionDetails);
	    		publishMessageToOrderProcessorKafka(retrievedDbOrderSubmissionDetails);	
			}
			else
			{
				// failed 
				//DB updateyes
				retrievedDbOrderSubmissionDetails.setSubmissionStatus("in progress");
	    		orderProcessorRepository.updateOrderSubmissionDetails(retrievedDbOrderSubmissionDetails);
			}
		}
    }
    
    //Mocked SAG call
	private OrderSubmissionDetails sagCall(OrderSubmissionDetails orderSubmissionDetails) {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss"); 
		List<Prescription> listPrescriptions=orderSubmissionDetails.getPrescriptionsList();
    	for(Prescription prescription:listPrescriptions)
    	{
    		String PrescriptionId= prescription.getPrescriptionId();
    		if(PrescriptionId.equalsIgnoreCase("asprin"))
    		{
    			prescription.setSubmissionStatus("failed");
    		}
    		else 
    		{
    			prescription.setSubmissionStatus("success");
    		}
    		
    		 		
    		prescription.setRetryDateTm(dateFormat.format(new Date()));    		
    	}
    	
    	orderSubmissionDetails.setUpdateDateTm(dateFormat.format(new Date()));
    	
    	return orderSubmissionDetails;
	}
	
	private String publishMessageToOrderErrorKafka(OrderSubmissionDetails orderSubmissionDetails) {
		kafkaTemplate.send(failedTopic, orderSubmissionDetails);
		System.out.println("Published successfully to error topic\n\n");
        return "Published successfully to FAILEDTOPIC";
	}


	private String publishMessageToOrderProcessorKafka(OrderSubmissionDetails orderSubmissionDetails) {
		kafkaTemplate.send(successTopic, orderSubmissionDetails);
		System.out.println("Published successfully to order processor results kafka topic\n\n");
        return "Published successfully to SUCCESSTOPIC";
	}
}
