package com.wba.eapi.eapirxorderprocessor.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.wba.eapi.eapirxorderprocessor.model.OrderSubmissionDetails;
import com.wba.eapi.eapirxorderprocessor.model.Prescription;

@Repository
public class OrderProcessorRepository {

	@Autowired
	MongoTemplate mongoTemplate;

	public void insertOrderSubmissionDetails(OrderSubmissionDetails orderSubmissionDetails) {
		if (getOrderSubmissionDetailByOrderId(orderSubmissionDetails.getOrderId()) == null) {
			mongoTemplate.insert(orderSubmissionDetails);
			System.out.println("its a new order - Inserted OrderSubmissionDetails successfully\n\n");
		} else
			System.out.println("its an old order -OrderSubmissionDetails already existed-Not inserting again\n\n");

	}

	public String updateOrderSubmissionDetails(OrderSubmissionDetails orderSubmissionDetails) {
		OrderSubmissionDetails retrievedOrderSubmissionDetails = getOrderSubmissionDetailByOrderId(orderSubmissionDetails.getOrderId());
		
		if (retrievedOrderSubmissionDetails != null) {
			
			for (Prescription dbPrescription : retrievedOrderSubmissionDetails.getPrescriptionsList()) {
				for (Prescription newPrescription : orderSubmissionDetails.getPrescriptionsList()) {
					if (dbPrescription.getLineItem().equals(newPrescription.getLineItem()))
						dbPrescription.setSubmissionStatus(newPrescription.getSubmissionStatus());
					    dbPrescription.setRetryDateTm(newPrescription.getRetryDateTm());
					    dbPrescription.setRetryCount(newPrescription.getRetryCount());
				}
			}
			retrievedOrderSubmissionDetails.setSubmissionStatus(orderSubmissionDetails.getSubmissionStatus());
			retrievedOrderSubmissionDetails.setUpdateDateTm(orderSubmissionDetails.getUpdateDateTm());
		}
		mongoTemplate.save(retrievedOrderSubmissionDetails);

		return "Updated OrderSubmissionDetails successfully";
	}

	public OrderSubmissionDetails showAllOrderSubmissionDetails() {
		OrderSubmissionDetails orderSubmissionDetails = (OrderSubmissionDetails) mongoTemplate
				.findAll(OrderSubmissionDetails.class, "OrderSubmissionDetails");

		return orderSubmissionDetails;
	}

	public OrderSubmissionDetails getOrderSubmissionDetailByOrderId(String orderId) {
		Query query = new Query(Criteria.where("orderId").is(orderId));
		Optional<OrderSubmissionDetails> optional = Optional
				.ofNullable(mongoTemplate.findOne(query, OrderSubmissionDetails.class));
		return optional.orElse(null);
	}

}
