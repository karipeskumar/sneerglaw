﻿© 2020 Walgreens Boots Alliance, Inc.<br/>

## OrderProcessor

**Id:** eapi-rx-orderprocessor <br/>
**Short Id:** eapirxorderprocessor <br/>
**Description:** This service is used to fetch the data from Kafka,insert into DB and send for process Order <br/>
**Design Pattern:** Kafka-Kafka  

