import com.wba.api.boilerplate.controller.EapirxorderprocessorController;
import com.wba.api.boilerplate.service.EapirxorderprocessorServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;

@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)

@ContextConfiguration(
        classes = {
                EapirxorderprocessorController.class,
                EapirxorderprocessorServiceImpl.class,

        }, loader = AnnotationConfigContextLoader.class, initializers = ConfigFileApplicationContextInitializer.class)
public class EapirxorderprocessorUnitTests {

    private static final Logger logger = LoggerFactory.getLogger(EapirxorderprocessorUnitTests.class);
    @Autowired
    EapirxorderprocessorController eapirxorderprocessorController;

    @Test
    public void getSampleResponse() {
        logger.info("Testing Boilerplate API");

        String expectedResponse = "{\"ID\":\"1\"}";

        String actualResponse = eapirxorderprocessorController.getResponse("1").toString();
        System.out.println("OUTPUT======" + actualResponse);
        Assert.assertEquals("Sample outcome:", expectedResponse, actualResponse);

    }


}
