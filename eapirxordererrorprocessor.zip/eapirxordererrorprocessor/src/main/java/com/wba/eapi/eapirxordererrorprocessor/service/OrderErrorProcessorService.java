package com.wba.eapi.eapirxordererrorprocessor.service;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import com.wba.eapi.eapirxordererrorprocessor.model.OrderSubmissionDetails;
import com.wba.eapi.eapirxordererrorprocessor.model.Prescription;

@Service
@PropertySource("classpath:application.properties")
public class OrderErrorProcessorService {	
	
	@Autowired
    private KafkaTemplate<String, OrderSubmissionDetails> kafkaTemplate;
	
	@Value("${kafka-topic-order}")
	private String orderKafkaTopic = "";


    @KafkaListener(topics = "${kafka-topic-ordererror}", groupId = "${kafka.consumer.groupid}",
            containerFactory = "orderKafkaListenerFactory")
    public void consumeOrderFromErrorKafka(OrderSubmissionDetails orderSubmissionDetails, Acknowledgment acknowledgment) throws ParseException {
       
    	System.out.println("*************************************************");
    	System.out.println("\n\nmessage read from kafka topic \n\n"+orderSubmissionDetails+"\n\n");
    	
    	List<Prescription> prescriptionList=orderSubmissionDetails.getPrescriptionsList();
    	
    	int retryCount = prescriptionList.get(0).getRetryCount();

    	System.out.println("retry count when we pull data from Order Error Kafka " + retryCount+"\n\n");
    
    	
    	//Date updateTime = prescriptionList.get(0).getUpdateTime();
    	SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss");
    	
    	String updateTimeString = prescriptionList.get(0).getRetryDateTm();
    	System.out.println("retry update time when we pull data from Order Error Kafka " + updateTimeString+"\n\n");
    	Date updateTime=ft.parse(updateTimeString);
    
    	Long updateTimeInMs = updateTime.getTime()+ (1*60*1000);
    	Long currentTimeInMs =  Calendar.getInstance().getTimeInMillis();
    
    	if(retryCount<10)
    	{
    		if((currentTimeInMs-updateTimeInMs)>=0)
    		{
    			prescriptionList.get(0).setRetryCount(retryCount+1);
    			publishMessageToOrderMSKafka(orderSubmissionDetails);
    			System.out.println("Published successfully to Order MS Kafka topic\n\n");
    			
    		}
    		else
        	{
        		acknowledgment.nack(updateTimeInMs-currentTimeInMs);
        		System.out.println("waiting for"+ ((updateTimeInMs-currentTimeInMs)/1000) + "secs \n\n");
        	}	
    	}
    }

	private String publishMessageToOrderMSKafka(OrderSubmissionDetails orderSubmissionDetails) {
		System.out.println("Retry Count when publishing to kafka: " +orderSubmissionDetails.getPrescriptionsList().get(0).getRetryCount());
		kafkaTemplate.send(orderKafkaTopic, orderSubmissionDetails);
		System.out.println("Published successfully to Order Kafka\n\n");
        return "Published successfully to Order MS Kafka topic";
	}
}
