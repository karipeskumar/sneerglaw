package com.wba.eapi.eapirxordererrorprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;


@EnableAutoConfiguration
@org.springframework.boot.autoconfigure.SpringBootApplication
public class SpringBootApplication {

    public static void main(String[] args) {
    	System.out.println("*********************Application Started*****************************");
        SpringApplication.run(SpringBootApplication.class, args);
    }


}