﻿© 2020 Walgreens Boots Alliance, Inc.<br/>

## OrderProcessor

**Id:** eapi-rx-ordererrorprocessor <br/>
**Short Id:** eapirxordererrorprocessor <br/>
**Description:** This service is used to fetch the data from Kafka,insert into DB and send for process Order<br/>
**Design Pattern:** Kafka-Kafka  

